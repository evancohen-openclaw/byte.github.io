---
name: elevenlabs-call
description: Initiate outbound phone calls using ElevenLabs Conversational AI agents. Use when the user asks to call them, make a phone call, or have a voice conversation.
---

# ElevenLabs Outbound Calls

Initiate contextual calls via the ElevenLabs Twilio integration.

## Setup

Before using this skill, you'll need:

1. **ElevenLabs API Key** - Get one at [elevenlabs.io](https://elevenlabs.io)
2. **Conversational AI Agent** - Create one in the ElevenLabs dashboard
3. **Phone Number** - Purchase/configure a Twilio number through ElevenLabs

| Resource | Value |
|----------|-------|
| Agent | Your Agent (`YOUR_AGENT_ID`) |
| Phone Number | Your Number (`YOUR_PHONE_NUMBER_ID`) |
| Target Number | The number to call |
| API Key | `$(openclaw config get skills.entries.sag.apiKey -q)` |

## Call Someone With Context

Use `conversation_initiation_client_data` to override the prompt and first message dynamically:

```bash
curl -s -X POST "https://api.elevenlabs.io/v1/convai/twilio/outbound-call" \
  -H "xi-api-key: $(openclaw config get skills.entries.sag.apiKey -q)" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_id": "YOUR_AGENT_ID",
    "agent_phone_number_id": "YOUR_PHONE_NUMBER_ID",
    "to_number": "+1XXXXXXXXXX",
    "conversation_initiation_client_data": {
      "type": "conversation_initiation_client_data",
      "conversation_config_override": {
        "agent": {
          "prompt": {
            "prompt": "You are an AI assistant making a call. Purpose: {{purpose}}. Be brief and direct. Ask at most one question. If they decline or are busy, offer to follow up via text and end the call politely."
          },
          "first_message": "Hey—{{first_message}}"
        }
      },
      "dynamic_variables": {
        "purpose": "<why you are calling>",
        "first_message": "<opening line - what you need>"
      }
    }
  }'
```

### Example: Permission Request

```bash
curl -s -X POST "https://api.elevenlabs.io/v1/convai/twilio/outbound-call" \
  -H "xi-api-key: $(openclaw config get skills.entries.sag.apiKey -q)" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_id": "YOUR_AGENT_ID",
    "agent_phone_number_id": "YOUR_PHONE_NUMBER_ID",
    "to_number": "+1XXXXXXXXXX",
    "conversation_initiation_client_data": {
      "type": "conversation_initiation_client_data",
      "conversation_config_override": {
        "agent": {
          "prompt": {
            "prompt": "You are an AI assistant making a call. Purpose: {{purpose}}. Be brief and direct. Ask at most one question. If they decline or are busy, offer to follow up via text and end the call politely."
          },
          "first_message": "Hey—{{first_message}}"
        }
      },
      "dynamic_variables": {
        "purpose": "Ask permission to post a thread on Twitter about a new integration",
        "first_message": "Quick question—I want to post about our new voice call setup on Twitter. Cool with you?"
      }
    }
  }'
```

## Simple Call (No Context)

For a basic call without overrides:

```bash
curl -s -X POST "https://api.elevenlabs.io/v1/convai/twilio/outbound-call" \
  -H "xi-api-key: $(openclaw config get skills.entries.sag.apiKey -q)" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_id": "YOUR_AGENT_ID",
    "agent_phone_number_id": "YOUR_PHONE_NUMBER_ID",
    "to_number": "+1XXXXXXXXXX"
  }'
```

## API Reference

### List agents
```bash
curl -s "https://api.elevenlabs.io/v1/convai/agents" \
  -H "xi-api-key: $API_KEY" | jq '.agents[] | {agent_id, name}'
```

### List phone numbers
```bash
curl -s "https://api.elevenlabs.io/v1/convai/phone-numbers" \
  -H "xi-api-key: $API_KEY" | jq '.[] | {phone_number_id, phone_number, label}'
```

## After the Call: Get Transcript

Poll the conversation endpoint to get status and transcript:

```bash
curl -s "https://api.elevenlabs.io/v1/convai/conversations/$CONVERSATION_ID" \
  -H "xi-api-key: $API_KEY" | jq '{status, transcript, analysis}'
```

- `status`: "processing" → "done" (or "failed")
- `transcript`: Array of `{role, message, time_in_call_secs}`
- `analysis.transcript_summary`: AI-generated summary

## Notes

- Phone numbers must be E.164 format (e.g., `+15551234567`)
- Response includes `conversation_id` and `callSid` on success
- Poll conversation endpoint after call to get transcript

## Troubleshooting

### "Override for field X is not allowed by config"

The agent must have overrides enabled. Patch it:

```bash
curl -s -X PATCH "https://api.elevenlabs.io/v1/convai/agents/$AGENT_ID" \
  -H "xi-api-key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "platform_settings": {
      "overrides": {
        "conversation_config_override": {
          "agent": {
            "first_message": true,
            "prompt": { "prompt": true }
          }
        }
      }
    }
  }'
```
